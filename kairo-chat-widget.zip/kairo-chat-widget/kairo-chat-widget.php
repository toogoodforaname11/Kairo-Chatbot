<?php
/**
 * Plugin Name: Kairo Chat Widget
 * Plugin URI: https://kairo.chat
 * Description: Animated holographic orb chatbot widget powered by Voiceflow.
 * Version: 1.0.0
 * Author: Kairo
 * License: GPL v2 or later
 */

if (!defined('ABSPATH')) exit;

add_action('admin_menu', 'kairo_chat_menu');
add_action('admin_init', 'kairo_chat_settings');
add_action('wp_enqueue_scripts', 'kairo_chat_enqueue');

function kairo_chat_enqueue() {
    if (is_admin() || !get_option('kairo_enabled', true)) return;
    wp_enqueue_style('kairo-dm-sans', 'https://fonts.googleapis.com/css2?family=DM+Sans:wght@400;500;600;700&display=swap', array(), null);
}

function kairo_chat_menu() {
    add_options_page('Kairo Chat', 'Kairo Chat', 'manage_options', 'kairo-chat', 'kairo_chat_page');
}

function kairo_chat_settings() {
    register_setting('kairo_opts', 'kairo_api_key', ['sanitize_callback'=>'sanitize_text_field','default'=>'VF.DM.69caaa8be9aebe38455e6741.RjGwLQQ80TA7DGqN']);
    register_setting('kairo_opts', 'kairo_version', ['sanitize_callback'=>'sanitize_text_field','default'=>'production']);
    register_setting('kairo_opts', 'kairo_name', ['sanitize_callback'=>'sanitize_text_field','default'=>'Kairo']);
    register_setting('kairo_opts', 'kairo_enabled', ['type'=>'boolean','default'=>true]);
}

function kairo_chat_page() {
    ?>
    <div class="wrap">
        <h1>Kairo Chat Widget</h1>
        <form method="post" action="options.php">
            <?php settings_fields('kairo_opts'); ?>
            <table class="form-table">
                <tr><th><label for="kairo_enabled">Enable</label></th>
                    <td><input type="checkbox" name="kairo_enabled" value="1" <?php checked(get_option('kairo_enabled',true)); ?>/></td></tr>
                <tr><th><label for="kairo_api_key">Voiceflow API Key</label></th>
                    <td><input type="text" name="kairo_api_key" value="<?php echo esc_attr(get_option('kairo_api_key','VF.DM.69caaa8be9aebe38455e6741.RjGwLQQ80TA7DGqN')); ?>" class="regular-text"/>
                    <p class="description">Your Voiceflow Dialog Manager API key (starts with VF.DM.)</p></td></tr>
                <tr><th><label for="kairo_version">Version</label></th>
                    <td><input type="text" name="kairo_version" value="<?php echo esc_attr(get_option('kairo_version','production')); ?>" class="regular-text"/></td></tr>
                <tr><th><label for="kairo_name">Bot Name</label></th>
                    <td><input type="text" name="kairo_name" value="<?php echo esc_attr(get_option('kairo_name','Kairo')); ?>" class="regular-text"/></td></tr>
            </table>
            <?php submit_button(); ?>
        </form>
    </div>
    <?php
}

add_action('wp_footer', 'kairo_chat_widget');
function kairo_chat_widget() {
    if (is_admin() || !get_option('kairo_enabled', true)) return;
    $api = esc_js(get_option('kairo_api_key', 'VF.DM.69caaa8be9aebe38455e6741.RjGwLQQ80TA7DGqN'));
    $ver = esc_js(get_option('kairo_version', 'production'));
    $nm  = esc_html(get_option('kairo_name', 'Kairo'));
?>
<!-- KAIRO CHAT WIDGET -->
<style>
.kairo-root,.kairo-root *{box-sizing:border-box;margin:0;padding:0;font-family:'DM Sans',-apple-system,sans-serif;-webkit-font-smoothing:antialiased}
.kairo-root{position:fixed;bottom:50px;right:20px;z-index:99999;transition:bottom .3s ease}
.kairo-orb-btn{width:120px;height:120px;cursor:pointer;transition:transform .3s ease;border:none;background:none;padding:0}
.kairo-orb-btn:hover{transform:scale(1.08)}
.kairo-orb-btn canvas{display:block;width:120px;height:120px}
.kairo-window{position:absolute;bottom:0;right:0;width:370px;height:560px;border-radius:16px;overflow:hidden;display:flex;flex-direction:column;background:#0A0E1A;box-shadow:0 12px 48px rgba(0,0,0,.15),0 4px 16px rgba(0,0,0,.08);opacity:0;transform:translateY(8px) scale(.96);pointer-events:none;transition:opacity .25s ease,transform .25s ease}
.kairo-window.visible{opacity:1;transform:translateY(0) scale(1);pointer-events:auto}
.kairo-hd{background:linear-gradient(155deg,#0a1628,#122242 60%,#1a3060);padding:14px 16px 10px;display:flex;align-items:stretch;gap:10px;flex-shrink:0}
.kairo-hd-av{width:38px;height:38px;border-radius:50%;overflow:hidden;flex-shrink:0;background:#080e1c;border:2px solid rgba(100,160,240,.25);align-self:center}
.kairo-hd-av canvas{width:38px;height:38px;display:block}
.kairo-hd-txt{flex:1;display:flex;flex-direction:column;justify-content:space-between}
.kairo-hd-nm{font-size:18px;font-weight:800;line-height:1.2;background:linear-gradient(90deg,#c2e2fb,#5a9fd6);-webkit-background-clip:text;-webkit-text-fill-color:transparent;background-clip:text}
.kairo-hd-st{display:flex;align-items:center;gap:5px;margin-top:auto}
.kairo-hd-lb{font-size:11px;color:rgba(200,210,225,.6)}
.kairo-hd-dot{width:6px;height:6px;border-radius:50%;background:#34d399;box-shadow:0 0 6px rgba(52,211,153,.5)}
.kairo-hd-on{font-size:11px;color:#34d399;font-weight:600}
.kairo-hd-acts{display:flex;gap:5px;flex-shrink:0;align-self:center}
.kairo-hd-btn{width:30px;height:30px;border-radius:50%;background:rgba(255,255,255,.08);border:none;cursor:pointer;display:flex;align-items:center;justify-content:center;color:rgba(255,255,255,.5);font-size:16px;line-height:1;transition:all .15s;flex-shrink:0}
.kairo-hd-btn:hover{background:rgba(255,255,255,.15);color:#fff}
.kairo-body{flex:1;overflow-y:auto;padding:18px 14px 10px;background:#0A0E1A;display:flex;flex-direction:column;scroll-behavior:smooth;min-height:0}
.kairo-body::-webkit-scrollbar{width:3px}
.kairo-body::-webkit-scrollbar-thumb{background:rgba(255,255,255,.08);border-radius:10px}
.kairo-empty{flex:1;display:flex;flex-direction:column;align-items:center;justify-content:center;text-align:center;padding:0;background:#0A0E1A;overflow:hidden;position:relative}
.kairo-empty::before{content:'';position:absolute;top:50%;left:50%;width:400px;height:400px;margin:-200px 0 0 -200px;border-radius:50%;background:radial-gradient(circle,rgba(0,200,255,.7) 0%,rgba(0,140,255,.4) 20%,rgba(0,100,220,.15) 45%,transparent 65%);animation:kBurst 1.8s ease-out .2s both;z-index:0}
@keyframes kBurst{0%{transform:scale(0);opacity:0}15%{opacity:1}40%{transform:scale(1);opacity:.9}70%{transform:scale(1.6);opacity:.3}100%{transform:scale(2);opacity:0}}
.kairo-empty::after{content:'';position:absolute;top:0;left:0;width:100%;height:100%;z-index:3;pointer-events:none;background:linear-gradient(180deg,transparent 0%,rgba(0,180,255,.12) 2%,rgba(0,200,255,.2) 4%,transparent 8%),linear-gradient(180deg,transparent 0%,rgba(0,160,255,.08) 3%,transparent 7%);background-size:100% 300%,100% 400%;animation:kFlow 2.5s ease-in 1.2s infinite,kFlow2 3.5s ease-in 1.8s infinite}
@keyframes kFlow{0%{background-position:0 -200%,0 0}100%{background-position:0 200%,0 0}}
@keyframes kFlow2{0%{background-position:0 0,0 -300%}100%{background-position:0 0,0 300%}}

.kairo-empty-t{position:relative;z-index:4;font-size:16px;font-weight:700;color:#e2e8f0;margin-bottom:4px;text-shadow:0 2px 8px rgba(0,0,0,.7)}.kairo-empty-s{position:relative;z-index:4;font-size:13px;color:#94a3b8;line-height:1.5;text-shadow:0 2px 8px rgba(0,0,0,.7)}
.kairo-bot{display:flex;gap:8px;align-items:flex-start;margin-bottom:12px;animation:kS .3s ease both}
@keyframes kS{from{opacity:0;transform:translateY(6px)}to{opacity:1;transform:translateY(0)}}
.kairo-av{width:26px;height:26px;border-radius:50%;flex-shrink:0;background:#101c38;display:flex;align-items:center;justify-content:center;margin-top:2px}
.kairo-av svg{width:15px;height:15px}
.kairo-bb{background:#1a2538;border-radius:4px 16px 16px 16px;padding:11px 14px;max-width:80%;font-size:14px;line-height:1.65;color:#e2e8f0;box-shadow:0 1px 4px rgba(0,0,0,.12);word-wrap:break-word}
.kairo-bb strong{font-weight:700;color:#fff}.kairo-bb a{color:#60a5fa;text-decoration:none;font-weight:600}.kairo-bb a:hover{text-decoration:underline}
.kairo-usr{display:flex;justify-content:flex-end;margin-bottom:12px;animation:kS .2s ease both}
.kairo-ub{background:linear-gradient(135deg,#2e6dcc,#5ba3e6 50%,#7cc8f8);border-radius:16px 4px 16px 16px;padding:11px 14px;max-width:78%;font-size:14px;line-height:1.6;color:#fff;box-shadow:0 2px 10px rgba(46,109,204,.3);word-wrap:break-word}
.kairo-typ{display:flex;gap:8px;align-items:flex-start;margin-bottom:12px;animation:kS .2s ease both}
.kairo-empty~.kairo-typ{display:none}
.kairo-tb{background:#1a2538;border-radius:4px 16px 16px 16px;padding:14px 18px;display:flex;gap:5px;align-items:center;box-shadow:0 1px 4px rgba(0,0,0,.12)}
.kairo-td{width:6px;height:6px;border-radius:50%;background:#3b82f6}
.kairo-td:nth-child(1){animation:kB 1.2s ease-in-out 0s infinite}.kairo-td:nth-child(2){animation:kB 1.2s ease-in-out .2s infinite}.kairo-td:nth-child(3){animation:kB 1.2s ease-in-out .4s infinite}
@keyframes kB{0%,80%,100%{transform:scale(.4);opacity:.2}40%{transform:scale(1.1);opacity:1}}
.kairo-chs{margin-left:34px;margin-bottom:12px;display:flex;flex-wrap:wrap;gap:6px;animation:kS .28s ease both}
.kairo-ch{padding:9px 16px;border-radius:22px;font-size:13.5px;font-weight:600;cursor:pointer;font-family:'DM Sans',sans-serif;background:#111927;color:#cbd5e1;border:1px solid rgba(59,130,246,0.6);box-shadow:0 1px 3px rgba(0,0,0,.08);transition:all .18s ease;display:flex;align-items:center;justify-content:center;text-align:center;line-height:1.35;min-height:38px;box-sizing:border-box}
.kairo-ch:hover{border-color:#06b6d4;color:#06b6d4;box-shadow:0 0 0 2px rgba(6,182,212,.1),0 3px 10px rgba(6,182,212,.12);transform:translateY(-1px)}.kairo-ch:active{transform:scale(.97)}
.kairo-ch-half{flex:0 0 calc(50% - 3px)}
.kairo-ch-full{flex:0 0 100%}
.kairo-card{max-width:80%;background:#1a2538;border-radius:4px 16px 16px 16px;overflow:hidden;box-shadow:0 1px 4px rgba(0,0,0,.12);animation:kS .25s ease both}
.kairo-ci{padding:12px 14px}.kairo-ct{font-size:14px;font-weight:700;color:#f1f5f9;margin-bottom:4px}.kairo-cd{font-size:13.5px;color:#94a3b8;line-height:1.6}
.kairo-ca{display:flex;flex-direction:column;gap:6px;margin-top:8px;padding-top:8px;border-top:1px solid rgba(255,255,255,.06)}
.kairo-cb{width:100%;display:flex;align-items:center;justify-content:space-between;padding:9px 12px;background:#111927;border:1px solid rgba(59,130,246,0.6);border-radius:10px;color:#cbd5e1;font-size:13px;font-weight:600;cursor:pointer;transition:all .15s;text-align:left;font-family:inherit}
.kairo-cb:hover{border-color:#06b6d4;color:#06b6d4;background:#111927}
.kairo-bb .mh{font-size:13px;font-weight:700;color:#fff;margin:5px 0 2px}.kairo-bb .mu{margin:3px 0 3px 16px;padding:0;list-style:disc}.kairo-bb .mu li{font-size:13.5px;line-height:1.6;color:#cbd5e1}.kairo-bb .ms{height:5px}.kairo-bb .ml{margin:1px 0;line-height:1.6}
.kairo-ft{padding:10px 12px;border-top:1px solid rgba(255,255,255,.06);background:#0A0E1A;flex-shrink:0;display:flex;gap:8px;align-items:center}
.kairo-ft input{flex:1;padding:10px 16px;border:1.5px solid rgba(255,255,255,.1);border-radius:24px;font-size:14px;font-family:'DM Sans',sans-serif;outline:none;color:#e2e8f0;background:#141E2E;transition:all .2s}
.kairo-ft input::placeholder{color:rgba(148,163,184,.5)}.kairo-ft input:focus{border-color:#3b82f6;box-shadow:0 0 0 3px rgba(59,130,246,.08);background:#1a2840}.kairo-ft input:disabled{opacity:.45;background:#0f1620}
.kairo-sb{width:40px;height:40px;border-radius:50%;background:linear-gradient(135deg,#2e6dcc,#5ba3e6 50%,#7cc8f8);border:none;cursor:pointer;display:flex;align-items:center;justify-content:center;flex-shrink:0;transition:all .2s;box-shadow:0 2px 8px rgba(46,109,204,.3)}
.kairo-sb:hover:not(:disabled){background:linear-gradient(135deg,#2560b8,#4e94d9 50%,#6db8ec);box-shadow:0 3px 14px rgba(46,109,204,.4);transform:scale(1.05)}.kairo-sb:disabled{opacity:.25;cursor:default;box-shadow:none}.kairo-sb svg{stroke:#fff;width:17px;height:17px}
.kairo-br{padding:4px 6px;text-align:center;background:#141E2E;border-top:1px solid rgba(255,255,255,.04);flex-shrink:0}.kairo-br span{font-size:10px;color:rgba(148,163,184,.35);letter-spacing:.8px;font-weight:600;text-transform:uppercase}.kairo-br .kairo-br-name{background:linear-gradient(90deg,#c2e2fb,#5a9fd6);-webkit-background-clip:text;-webkit-text-fill-color:transparent;background-clip:text;font-weight:800}
@media(max-width:480px){
.kairo-root{bottom:38px;right:14px}
.kairo-orb-btn{width:114px;height:114px}
.kairo-orb-btn canvas{width:114px;height:114px}
.kairo-window{position:fixed;top:0;left:0;right:0;bottom:0;width:100vw;max-width:100vw;height:100%;border-radius:0;max-height:none;box-shadow:none;box-sizing:border-box;z-index:999999}
.kairo-hd{padding:12px 14px 8px;border-radius:0;min-height:52px}
.kairo-hd-av{width:32px;height:32px}
.kairo-hd-av canvas{width:32px;height:32px}
.kairo-hd-nm{font-size:16px}
.kairo-body{padding:12px 12px 6px;flex:1;min-height:0;overflow-y:auto;-webkit-overflow-scrolling:touch}
.kairo-bb,.kairo-ub{max-width:85%;font-size:14px}
.kairo-ft{display:flex;flex-direction:row;align-items:center;gap:8px;width:100%;box-sizing:border-box;padding:8px 10px;padding-bottom:calc(10px + env(safe-area-inset-bottom,0px))}
.kairo-ft input{flex:1;min-width:0;width:auto;font-size:16px;padding:10px 14px}
.kairo-sb{flex-shrink:0}
.kairo-chs{margin-left:34px}
.kairo-br{padding:3px 6px}
}
.kairo-type{position:absolute;top:128px;right:0;text-align:center;font-family:'Courier New',Courier,monospace;font-size:18px;font-weight:bold;letter-spacing:1px;color:#fff;pointer-events:none;white-space:nowrap;transition:opacity .3s;text-shadow:0 0 2px #fff,0 0 4px #fff,0 0 8px #fff,0 0 14px rgba(160,220,255,.7),0 0 22px rgba(100,190,255,.3);background:rgba(8,14,28,.85);padding:6px 16px;border-radius:10px;z-index:0;min-height:20px;line-height:20px;overflow:visible}
.kairo-type-x{position:absolute;top:-9px;right:-9px;width:18px;height:18px;border:1px solid rgba(123,184,224,.4);background:rgba(8,14,28,.5);color:transparent;font-size:0;cursor:pointer;pointer-events:auto;border-radius:50%;transition:all .2s;padding:0;display:flex;align-items:center;justify-content:center}
.kairo-type-x::after{content:'×';font-size:11px;line-height:1;margin-top:-1px;background:linear-gradient(135deg,#a8d4f0,#7bb8e0,#9dcbee);-webkit-background-clip:text;-webkit-text-fill-color:transparent;background-clip:text}
.kairo-type-x:hover{border-color:rgba(123,184,224,.7)}
.kairo-orb-btn{position:relative;z-index:1}
.kairo-type .kairo-cursor{animation:kCB 1s step-end infinite;text-shadow:0 0 2px #fff,0 0 5px #fff,0 0 10px #fff,0 0 16px rgba(160,220,255,.8),0 0 26px rgba(100,190,255,.35)}
@keyframes kCB{0%,50%{opacity:1}51%,100%{opacity:0}}
@media(max-width:480px){.kairo-type{font-size:14px;padding:4px 12px;top:122px;min-height:16px;line-height:16px}}
.vfrc-launcher,.vfrc-widget,.vfrc-launcher-button{display:none!important;visibility:hidden!important;width:0!important;height:0!important;opacity:0!important;pointer-events:none!important}
</style>
<div class="kairo-root" id="kR">
<div class="kairo-window" id="kW">
<div class="kairo-hd">
<div class="kairo-hd-av"><canvas id="kHO"></canvas></div>
<div class="kairo-hd-txt"><div class="kairo-hd-nm"><?php echo $nm; ?></div><div class="kairo-hd-st"><span class="kairo-hd-lb">Virtual Assistant</span><span class="kairo-hd-dot"></span><span class="kairo-hd-on">Online</span></div></div>
<div class="kairo-hd-acts"><button class="kairo-hd-btn" id="kRef" title="Restart">↻</button><button class="kairo-hd-btn" id="kCls" title="Close">✕</button></div>
</div>
<div class="kairo-body" id="kB"><div class="kairo-empty" id="kE"></div></div>
<div class="kairo-ft"><input type="text" id="kI" placeholder="Type your message..." disabled autocomplete="off"/><button class="kairo-sb" id="kS" disabled><svg viewBox="0 0 24 24" fill="none" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><line x1="22" y1="2" x2="11" y2="13"/><polygon points="22 2 15 22 11 13 2 9 22 2"/></svg></button></div>
<div class="kairo-br"><span>Powered by <span class="kairo-br-name"><?php echo $nm; ?></span></span></div>
</div>
<button class="kairo-orb-btn" id="kO"><canvas id="kOC"></canvas></button>
<div class="kairo-type" id="kTy"><span id="kTyT"></span><span class="kairo-cursor">_</span><button class="kairo-type-x" id="kTyX">×</button></div>
</div>
<script>
(function(){
'use strict';
var API_KEY='<?php echo $api; ?>';
var RT='https://general-runtime.voiceflow.com';
var VER='<?php echo $ver; ?>';
var UID='k-'+Math.random().toString(36).slice(2,10);
var G3=[[1,1,0],[-1,1,0],[1,-1,0],[-1,-1,0],[1,0,1],[-1,0,1],[1,0,-1],[-1,0,-1],[0,1,1],[0,-1,1],[0,1,-1],[0,-1,-1]];
var PP=[151,160,137,91,90,15,131,13,201,95,96,53,194,233,7,225,140,36,103,30,69,142,8,99,37,240,21,10,23,190,6,148,247,120,234,75,0,26,197,62,94,252,219,203,117,35,11,32,57,177,33,88,237,149,56,87,174,20,125,136,171,168,68,175,74,165,71,134,139,48,27,166,77,146,158,231,83,111,229,122,60,211,133,230,220,105,92,41,55,46,245,40,244,102,143,54,65,25,63,161,1,216,80,73,209,76,132,187,208,89,18,169,200,196,135,130,116,188,159,86,164,100,109,198,173,186,3,64,52,217,226,250,124,123,5,202,38,147,118,126,255,82,85,212,207,206,59,227,47,16,58,17,182,189,28,42,223,183,170,213,119,248,152,2,44,154,163,70,221,153,101,155,167,43,172,9,129,22,39,253,19,98,108,110,79,113,224,232,178,185,112,104,218,246,97,228,251,34,242,193,238,210,144,12,191,179,162,241,81,51,145,235,249,14,239,107,49,192,214,31,181,199,106,157,184,84,204,176,115,121,50,45,127,4,150,254,138,236,205,93,222,114,67,29,24,72,243,141,128,195,78,66,215,61,156,180];
var PM=new Uint8Array(512);for(var i=0;i<512;i++)PM[i]=PP[i&255];
function d3(g,x,y,z){return g[0]*x+g[1]*y+g[2]*z}
function n3(xi,yi,zi){var F=1/3,G=1/6,s=(xi+yi+zi)*F,i=Math.floor(xi+s),j=Math.floor(yi+s),k=Math.floor(zi+s),t=(i+j+k)*G,x0=xi-(i-t),y0=yi-(j-t),z0=zi-(k-t);var i1,j1,k1,i2,j2,k2;if(x0>=y0){if(y0>=z0){i1=1;j1=0;k1=0;i2=1;j2=1;k2=0}else if(x0>=z0){i1=1;j1=0;k1=0;i2=1;j2=0;k2=1}else{i1=0;j1=0;k1=1;i2=1;j2=0;k2=1}}else{if(y0<z0){i1=0;j1=0;k1=1;i2=0;j2=1;k2=1}else if(x0<z0){i1=0;j1=1;k1=0;i2=0;j2=1;k2=1}else{i1=0;j1=1;k1=0;i2=1;j2=1;k2=0}}var x1=x0-i1+G,y1=y0-j1+G,z1=z0-k1+G,x2=x0-i2+2*G,y2=y0-j2+2*G,z2=z0-k2+2*G,x3=x0-1+.5,y3=y0-1+.5,z3=z0-1+.5,ii=i&255,jj=j&255,kk=k&255;var n0=0,n1=0,n2=0,n3=0,t0=.6-x0*x0-y0*y0-z0*z0;if(t0>0){t0*=t0;n0=t0*t0*d3(G3[PM[ii+PM[jj+PM[kk]]]%12],x0,y0,z0)}var t1=.6-x1*x1-y1*y1-z1*z1;if(t1>0){t1*=t1;n1=t1*t1*d3(G3[PM[ii+i1+PM[jj+j1+PM[kk+k1]]]%12],x1,y1,z1)}var t2=.6-x2*x2-y2*y2-z2*z2;if(t2>0){t2*=t2;n2=t2*t2*d3(G3[PM[ii+i2+PM[jj+j2+PM[kk+k2]]]%12],x2,y2,z2)}var t3=.6-x3*x3-y3*y3-z3*z3;if(t3>0){t3*=t3;n3=t3*t3*d3(G3[PM[ii+1+PM[jj+1+PM[kk+1]]]%12],x3,y3,z3)}return 32*(n0+n1+n2+n3)}
function lN(vx,vy,vz,t,sp,ls){var a=(t*sp/ls)*Math.PI*2,r=.6,tx=Math.cos(a)*r,ty=Math.sin(a)*r;return n3(vx*.5+tx,vy*.5+ty,vz*.5)*.78+n3(vx*1.3+tx*1.8,vy*1.3+ty*1.8,vz*1.3)*.22}
function mkIco(sub){var phi=(1+Math.sqrt(5))/2,v=[[-1,phi,0],[1,phi,0],[-1,-phi,0],[1,-phi,0],[0,-1,phi],[0,1,phi],[0,-1,-phi],[0,1,-phi],[phi,0,-1],[phi,0,1],[-phi,0,-1],[-phi,0,1]];v=v.map(function(p){var l=Math.sqrt(p[0]*p[0]+p[1]*p[1]+p[2]*p[2]);return[p[0]/l,p[1]/l,p[2]/l]});var f=[[0,11,5],[0,5,1],[0,1,7],[0,7,10],[0,10,11],[1,5,9],[5,11,4],[11,10,2],[10,7,6],[7,1,8],[3,9,4],[3,4,2],[3,2,6],[3,6,8],[3,8,9],[4,9,5],[2,4,11],[6,2,10],[8,6,7],[9,8,1]],mc={};function gm(a,b){var k=Math.min(a,b)+'_'+Math.max(a,b);if(mc[k]!==undefined)return mc[k];var va=v[a],vb=v[b],mx=(va[0]+vb[0])/2,my=(va[1]+vb[1])/2,mz=(va[2]+vb[2])/2,l=Math.sqrt(mx*mx+my*my+mz*mz);v.push([mx/l,my/l,mz/l]);mc[k]=v.length-1;return mc[k]}for(var s=0;s<sub;s++){var nf=[];for(var i=0;i<f.length;i++){var t=f[i],ab=gm(t[0],t[1]),bc=gm(t[1],t[2]),ca=gm(t[2],t[0]);nf.push([t[0],ab,ca],[t[1],bc,ab],[t[2],ca,bc],[ab,bc,ca])}f=nf}var es={},ed=[];for(var i=0;i<f.length;i++){var t=f[i],ps=[[t[0],t[1]],[t[1],t[2]],[t[2],t[0]]];for(var j=0;j<3;j++){var u=ps[j][0],w=ps[j][1],k=Math.min(u,w)+'_'+Math.max(u,w);if(!es[k]){es[k]=1;ed.push([u,w])}}}return{v:v,e:ed}}
function lerp(a,b,t){return a+(b-a)*t}
function hc(df,t){var h=(df*.6+t*.03)%1,r,g,b;if(h<.2){var p=h/.2;r=lerp(40,60,p);g=lerp(220,140,p);b=255}else if(h<.4){var p=(h-.2)/.2;r=lerp(60,130,p);g=lerp(140,80,p);b=255}else if(h<.6){var p=(h-.4)/.2;r=lerp(130,180,p);g=lerp(80,60,p);b=lerp(255,240,p)}else if(h<.8){var p=(h-.6)/.2;r=lerp(180,100,p);g=lerp(60,160,p);b=lerp(240,255,p)}else{var p=(h-.8)/.2;r=lerp(100,40,p);g=lerp(160,220,p);b=255}return{r:Math.round(r),g:Math.round(g),b:Math.round(b)}}
var LS=20,CF={idle:{nA:.18,nS:2,rS:.01,rd:47,pA:.025,pS:.3,gA:.68,lA:.76,bl:5},hover:{nA:.2,nS:2.2,rS:.015,rd:50,pA:.028,pS:.35,gA:.76,lA:.82,bl:7},listening:{nA:.24,nS:2.8,rS:.008,rd:48,pA:.035,pS:.45,gA:.8,lA:.88,bl:8},thinking:{nA:.22,nS:2.5,rS:.06,rd:50,pA:.035,pS:.4,gA:.8,lA:.85,bl:7},newMessage:{nA:.28,nS:3.2,rS:.008,rd:53,pA:.045,pS:.55,gA:.9,lA:.94,bl:10}};
var ico=mkIco(4),cur={},oS='listening',oH=false,chO=false,chSt=false,iOn=false;
for(var k in CF.listening)cur[k]=CF.listening[k];
function cFd(c){var t=Math.min(c,1);return .05+.95*t*Math.sqrt(t)}
function drawOrb(cv,W,H){
var x=cv.getContext('2d'),dp=devicePixelRatio||1;
if(!cv._s){cv.width=W*dp;cv.height=H*dp;x.setTransform(dp,0,0,dp,0,0);cv._s=1}
var ef=oH&&oS==='listening'?'hover':oS,tg=CF[ef];
for(var k in cur)cur[k]=lerp(cur[k],tg[k],.01);
var c=cur,t=performance.now()/1e3,mx=W/2,my=H/2;
x.clearRect(0,0,W,H);
var ry=t*c.rS,rx=.22+Math.sin(t*.018)*.025,cry=Math.cos(ry),sry=Math.sin(ry),crx=Math.cos(rx),srx=Math.sin(rx);
var pu=1+Math.sin(t*c.pS*Math.PI*2)*c.pA,R=c.rd*pu;
var pj=[];
for(var i=0;i<ico.v.length;i++){var vx=ico.v[i][0],vy=ico.v[i][1],vz=ico.v[i][2],n=lN(vx,vy,vz,t,c.nS,LS),d=1+n*c.nA,ax=vx*d,ay=vy*d,az=vz*d,bx=ax*cry-az*sry,bz=ax*sry+az*cry,by=ay*crx-bz*srx,bz2=ay*srx+bz*crx,sc=1/(1+bz2*.08);pj.push({x:mx+bx*R*sc,y:my+by*R*sc,z:bz2})}
var ae=[];
for(var i=0;i<ico.e.length;i++){var a=ico.e[i][0],b=ico.e[i][1],pa=pj[a],pb=pj[b],ex=(pa.x+pb.x)/2,ey=(pa.y+pb.y)/2,dx=ex-mx,dy=ey-my;ae.push({a:a,b:b,z:(pa.z+pb.z)/2,cd:Math.sqrt(dx*dx+dy*dy)/R})}
ae.sort(function(a,b){return a.z-b.z});
// Core glow — drawn FIRST, wires fade into this
x.save();x.globalCompositeOperation='screen';
var g0=x.createRadialGradient(mx,my,0,mx,my,R*.95);
g0.addColorStop(0,'rgba(140,215,255,'+(0.45*c.gA)+')');
g0.addColorStop(.15,'rgba(110,195,252,'+(0.35*c.gA)+')');
g0.addColorStop(.35,'rgba(70,155,240,'+(0.22*c.gA)+')');
g0.addColorStop(.55,'rgba(45,120,225,'+(0.12*c.gA)+')');
g0.addColorStop(.8,'rgba(30,85,200,'+(0.05*c.gA)+')');
g0.addColorStop(1,'rgba(20,60,150,0)');
x.fillStyle=g0;x.beginPath();x.arc(mx,my,R*.95,0,Math.PI*2);x.fill();
var g1=x.createRadialGradient(mx,my,0,mx,my,R*.55);
g1.addColorStop(0,'rgba(200,240,255,'+(0.55*c.gA)+')');
g1.addColorStop(.2,'rgba(150,215,252,'+(0.4*c.gA)+')');
g1.addColorStop(.5,'rgba(90,175,242,'+(0.2*c.gA)+')');
g1.addColorStop(.8,'rgba(50,130,225,'+(0.08*c.gA)+')');
g1.addColorStop(1,'rgba(40,110,210,0)');
x.fillStyle=g1;x.beginPath();x.arc(mx,my,R*.55,0,Math.PI*2);x.fill();
var g2=x.createRadialGradient(mx,my,0,mx,my,R*.3);
g2.addColorStop(0,'rgba(235,250,255,'+(0.5*c.gA)+')');
g2.addColorStop(.35,'rgba(190,235,253,'+(0.3*c.gA)+')');
g2.addColorStop(.7,'rgba(130,200,245,'+(0.12*c.gA)+')');
g2.addColorStop(1,'rgba(100,180,240,0)');
x.fillStyle=g2;x.beginPath();x.arc(mx,my,R*.3,0,Math.PI*2);x.fill();
x.restore();
// Glow — batched by depth, 2 center-distance sub-bands (inner faded, outer full)
x.save();x.lineCap='round';
for(var bd=0;bd<6;bd++){var lo=-1+(bd/6)*2,hi=-1+((bd+1)/6)*2,md=(lo+hi)/2,df=.15+.85*((md+1)/2),ba=df*c.gA*.12;if(ba<.005)continue;var cl=hc(df,t);x.lineWidth=2*df;x.shadowColor='rgba('+Math.round(cl.r*.5)+','+Math.round(cl.g*.5)+','+Math.round(cl.b*.8)+',0.25)';x.shadowBlur=c.bl*df*.6;
for(var s=0;s<3;s++){var cL=s===0?0:s===1?.33:.67,cH=s===0?.33:s===1?.67:99,fd=cFd((cL+cH)/2),al=ba*fd;if(al<.003)continue;x.strokeStyle='rgba('+cl.r+','+cl.g+','+cl.b+','+al+')';x.beginPath();for(var ei=0;ei<ae.length;ei++){var e=ae[ei];if(e.z<lo||e.z>=hi||e.cd<cL||e.cd>=cH)continue;x.moveTo(pj[e.a].x,pj[e.a].y);x.lineTo(pj[e.b].x,pj[e.b].y)}x.stroke()}}
x.restore();
// Wire — batched 10 depth × 3 center-dist, centerFade dims toward center
x.save();x.lineCap='round';x.shadowBlur=0;
for(var db=0;db<10;db++){
var dlo=-1+(db/10)*2,dhi=-1+((db+1)/10)*2,dmd=(dlo+dhi)/2,df=.15+.85*((dmd+1)/2);
var cl=hc(df,t),br=.5+df*.5;
for(var li=0;li<5;li++){
var clo=li/5,chi=(li+1)/5,fd=cFd((clo+chi)/2);
var al=df*c.lA*fd;
if(al<.01)continue;
x.strokeStyle='rgba('+Math.min(255,Math.round(cl.r*br))+','+Math.min(255,Math.round(cl.g*br))+','+Math.min(255,Math.round(cl.b*br))+','+al+')';
x.lineWidth=lerp(.08,.45,df)*fd;
x.beginPath();
for(var ei=0;ei<ae.length;ei++){var e=ae[ei];if(e.z<dlo||e.z>=dhi||e.cd<clo||e.cd>=chi)continue;x.moveTo(pj[e.a].x,pj[e.a].y);x.lineTo(pj[e.b].x,pj[e.b].y);}
x.stroke();}}
x.restore();
// Rim
x.save();x.globalCompositeOperation='screen';x.lineCap='round';
var rc=hc(.8,t+5);x.shadowColor='rgba('+rc.r+','+rc.g+','+rc.b+',0.1)';x.shadowBlur=5;x.strokeStyle='rgba('+rc.r+','+rc.g+','+rc.b+','+(0.07*c.gA)+')';x.lineWidth=.9;x.beginPath();
for(var ei=0;ei<ae.length;ei++){var e=ae[ei],df=(e.z+1)/2,rm=1-Math.abs(df-.55)*2.5;if(rm<.15)continue;x.moveTo(pj[e.a].x,pj[e.a].y);x.lineTo(pj[e.b].x,pj[e.b].y)}
x.stroke();x.restore();
// Ripple
var ef2=oH&&oS==='listening'?'hover':oS;
if(ef2==='listening'||ef2==='newMessage'){var pr=ef2==='newMessage'?1.8:3.2,ph=(t%pr)/pr,rr=R+ph*10,ra=Math.max(0,.16*(1-ph)),rc2=hc(ph,t);x.save();x.beginPath();x.arc(mx,my,rr,0,Math.PI*2);x.strokeStyle='rgba('+rc2.r+','+rc2.g+','+rc2.b+','+ra+')';x.lineWidth=.6*(1-ph*.3);x.shadowColor='rgba('+rc2.r+','+rc2.g+','+rc2.b+','+(ra*.2)+')';x.shadowBlur=4;x.stroke();x.restore()}}
var lC=document.getElementById('kOC'),hC=document.getElementById('kHO');
function anim(){drawOrb(lC,120,120);if(chO)drawOrb(hC,38,38);requestAnimationFrame(anim)}requestAnimationFrame(anim);
var win=document.getElementById('kW'),bd=document.getElementById('kB'),inp=document.getElementById('kI'),sb=document.getElementById('kS');
document.getElementById('kO').onclick=function(){chO?cls():opn()};
document.getElementById('kCls').onclick=cls;
document.getElementById('kRef').onclick=rst;
document.getElementById('kO').onmouseenter=function(){oH=true};
document.getElementById('kO').onmouseleave=function(){oH=false};
sb.onclick=snd;inp.onkeydown=function(e){if(e.key==='Enter')snd(e)};
function opn(){chO=true;win.classList.add('visible');hC._s=0;oS='newMessage';document.getElementById('kO').style.display='none';document.getElementById('kTy').style.opacity='0';
var vp=document.querySelector('meta[name="viewport"]');if(vp){vp._orig=vp.getAttribute('content');vp.setAttribute('content','width=device-width,initial-scale=1,maximum-scale=1,user-scalable=no')}
if(window.innerWidth<=480){document.body._ky=window.scrollY;document.body._bg=document.body.style.background;document.documentElement._bg=document.documentElement.style.background;document.body.style.overflow='hidden';document.body.style.position='fixed';document.body.style.width='100%';document.body.style.top=-document.body._ky+'px';document.body.style.background='#0A0E1A';document.documentElement.style.background='#0A0E1A'}
if(!chSt){chSt=true;vfx({type:'launch'})}setTimeout(function(){inp.focus();scr()},300)}
function cls(){chO=false;win.classList.remove('visible');oS='listening';document.getElementById('kO').style.display='';document.getElementById('kTy').style.opacity='';
var vp=document.querySelector('meta[name="viewport"]');if(vp&&vp._orig)vp.setAttribute('content',vp._orig);
if(document.body.style.position==='fixed'){var sy=document.body._ky||0;document.body.style.overflow='';document.body.style.position='';document.body.style.width='';document.body.style.top='';document.body.style.background=document.body._bg||'';document.documentElement.style.background=document.documentElement._bg||'';window.scrollTo(0,sy)}}
function rst(){UID='k-'+Math.random().toString(36).slice(2,10);bd.innerHTML='';var e=document.createElement('div');e.className='kairo-empty';e.id='kE';e.innerHTML='';bd.appendChild(e);off();vfx({type:'launch'})}
function snd(e){if(e)e.preventDefault();var v=inp.value.trim();if(!v||!iOn)return;uM(v);inp.value='';off();vfx({type:'text',payload:v})}
// Mobile keyboard: let iOS handle natively with position:fixed fullscreen
if(window.visualViewport){window.visualViewport.addEventListener('resize',function(){if(!chO)return;scr()})}
function on(){iOn=true;inp.disabled=false;sb.disabled=false;inp.placeholder='Type your message...'}
function off(){iOn=false;inp.disabled=true;sb.disabled=true;inp.placeholder='Please wait...'}
function scr(){requestAnimationFrame(function(){bd.scrollTop=bd.scrollHeight})}
function esc(t){return(t||'').replace(/&/g,'&amp;').replace(/</g,'&lt;').replace(/>/g,'&gt;')}
function imd(t){return t.replace(/\[(.+?)\]\((https?:\/\/[^)]+)\)/g,'<a href="$2" target="_blank">$1</a>').replace(/\*\*(.+?)\*\*/g,'<strong>$1</strong>').replace(/\*(.+?)\*/g,'<em>$1</em>')}
function rmd(t){if(!t)return'';var l=t.split('\n'),h='',i=0;while(i<l.length){var ln=l[i];if(/^##?\s+/.test(ln)){h+='<div class="mh">'+esc(ln.replace(/^##?\s+/,''))+'</div>';i++;continue}if(/^[-*•]\s+/.test(ln)){h+='<ul class="mu">';while(i<l.length&&/^[-*•]\s+/.test(l[i])){h+='<li>'+imd(l[i].replace(/^[-*•]\s+/,''))+'</li>';i++}h+='</ul>';continue}if(!ln.trim()){h+='<div class="ms"></div>';i++;continue}h+='<div class="ml">'+imd(ln)+'</div>';i++}return h}
function rmE(){var e=document.getElementById('kE');if(e)e.remove()}
var AV='<div class="kairo-av"><svg viewBox="2 0 20 19" fill="none" xmlns="http://www.w3.org/2000/svg"><line x1="12" y1="1" x2="12" y2="4" stroke="#e2e8f0" stroke-width="1.5" stroke-linecap="round"/><circle cx="12" cy="1.5" r="1.2" fill="#e2e8f0"/><rect x="3" y="4" width="18" height="14" rx="4" fill="#e2e8f0"/><circle cx="8.5" cy="10.5" r="2" fill="#0A0E1A"/><circle cx="15.5" cy="10.5" r="2" fill="#0A0E1A"/><path d="M9 14.5 Q12 16.5 15 14.5" stroke="#0A0E1A" stroke-width="1.2" stroke-linecap="round" fill="none"/></svg></div>';
function bM(t){if(!t)return;rmE();var r=document.createElement('div');r.className='kairo-bot';r.innerHTML=AV;var b=document.createElement('div');b.className='kairo-bb';b.innerHTML=rmd(t);r.appendChild(b);bd.appendChild(r);scr()}
function uM(t){rmE();var r=document.createElement('div');r.className='kairo-usr';r.innerHTML='<div class="kairo-ub">'+esc(t)+'</div>';bd.appendChild(r);scr()}
function sT(){rT();var r=document.createElement('div');r.className='kairo-typ';r.id='kT';r.innerHTML=AV+'<div class="kairo-tb"><span class="kairo-td"></span><span class="kairo-td"></span><span class="kairo-td"></span></div>';bd.appendChild(r);scr()}
function rT(){var e=document.getElementById('kT');if(e)e.remove()}
function rBt(){var e=document.getElementById('kCh');if(e)e.remove()}
function sBt(btns){rBt();if(!btns||!btns.length)return;var w=document.createElement('div');w.className='kairo-chs';w.id='kCh';bd.appendChild(w);var cv=document.createElement('canvas');var cx=cv.getContext('2d');cx.font='600 13.5px "DM Sans",-apple-system,sans-serif';var cw=w.offsetWidth||260;var halfMax=(cw-6)/2-34;if(halfMax<60)halfMax=100;var cls=btns.map(function(bn){var lb=bn.name||bn.label||bn.text||'?';var tw=cx.measureText(lb).width+50;return{bn:bn,lb:lb,size:tw<=halfMax?'half':'full'}});var hc=cls.filter(function(c){return c.size==='half'}).length;if(hc%2===1){for(var i=cls.length-1;i>=0;i--){if(cls[i].size==='half'){cls[i].size='full';break}}}cls.sort(function(a,b){return a.size==='half'&&b.size==='full'?-1:a.size==='full'&&b.size==='half'?1:0});cls.forEach(function(c){var b=document.createElement('button');b.className='kairo-ch kairo-ch-'+c.size;b.innerHTML='<span>'+esc(c.lb)+'</span>';b.onclick=function(){uM(c.lb);rBt();off();vfx(c.bn.request||{type:'text',payload:c.lb})};w.appendChild(b)});scr()}
function aCd(cd){rmE();var r=document.createElement('div');r.className='kairo-bot';r.innerHTML=AV;var ce=document.createElement('div');ce.className='kairo-card';var b='';if(cd.title)b+='<div class="kairo-ct">'+esc(cd.title)+'</div>';var ds=cd.description?.text||cd.description||cd.body||'';if(ds)b+='<div class="kairo-cd">'+rmd(ds)+'</div>';if(cd.buttons&&cd.buttons.length){b+='<div class="kairo-ca">';nB(cd.buttons).forEach(function(bn){b+='<button class="kairo-cb" data-r=\''+esc(JSON.stringify(bn.request))+'\'><span>'+esc(bn.name)+'</span><span>›</span></button>'});b+='</div>'}ce.innerHTML='<div class="kairo-ci">'+b+'</div>';ce.querySelectorAll('.kairo-cb').forEach(function(b){b.addEventListener('click',function(){var rq=JSON.parse(b.dataset.r);uM(b.querySelector('span').textContent);rBt();off();vfx(rq)})});r.appendChild(ce);bd.appendChild(r);scr()}
function nB(raw){return(raw||[]).map(function(b){var nm=b.name||b.label||b.text||b.title||'?',rq=b.request;if(!rq&&b.actions&&b.actions.length)rq={type:b.actions[0].type||'intent',payload:b.actions[0].payload||{}};if(!rq)rq={type:'text',payload:nm};return{name:nm,request:rq}})}
async function vfx(action){sT();rBt();off();oS='thinking';try{var r=await fetch(RT+'/state/user/'+UID+'/interact?logs=off',{method:'POST',headers:{'Content-Type':'application/json','Authorization':API_KEY,'versionID':VER},body:JSON.stringify({action:action})});if(!r.ok){var errText=await r.text();console.error('VF Error',r.status,errText);throw new Error(r.status)}var tr=await r.json();console.log('VF traces',tr);rT();oS=chO?'newMessage':'listening';proc(tr)}catch(e){rT();console.error('VF fetch error',e);oS=chO?'newMessage':'listening';bM("Sorry, I couldn't connect. Please try again.");on()}}
function proc(tr){var pb=[];for(var i=0;i<tr.length;i++){var t=tr[i];switch(t.type){case'text':case'speak':var m=t.payload?.message||t.payload?.body||t.payload?.text||'';if(m)bM(m);break;case'choice':var rw=t.payload?.buttons||t.payload?.choices||[];var bt=nB(rw);if(bt.length)pb=pb.concat(bt);break;case'cardV2':aCd(t.payload);break;case'carousel':(t.payload?.cards||[]).forEach(function(c){aCd(c)});break;case'end':break;default:var fb=t.payload?.buttons||t.payload?.choices||[];if(fb.length)pb=pb.concat(nB(fb))}}if(pb.length)sBt(pb);on()}
// Terminal typing animation
(function(){
var phrases=['Hello...','Have a question?','Ask me anything.'];
var pauses=[700,1000,2200];
var tySpd=60,delSpd=35;
var el=document.getElementById('kTyT');
var pi=0,ci=0,deleting=false;
function tick(){
var phrase=phrases[pi];
if(!deleting){
ci++;el.textContent=phrase.slice(0,ci);
if(ci>=phrase.length){setTimeout(function(){deleting=true;tick()},pauses[pi]);return}
setTimeout(tick,tySpd);
}else{
ci--;el.textContent=phrase.slice(0,ci);
if(ci<=0){deleting=false;pi=(pi+1)%phrases.length;setTimeout(tick,300);return}
setTimeout(tick,delSpd);
}}
setTimeout(tick,800);
})();
// Dismiss typing text for session
var tyBox=document.getElementById('kTy'),tyX=document.getElementById('kTyX');
tyX.onclick=function(e){e.stopPropagation();tyBox.style.display='none';document.querySelector('.kairo-root').style.bottom='20px'};
})();
</script>
<?php
}
